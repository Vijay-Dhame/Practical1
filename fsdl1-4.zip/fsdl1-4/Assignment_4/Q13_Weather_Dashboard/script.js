const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const d1 = [10, 20, 30, 40, 50, 60, 70];
const d2 = [5, 10, 15, 20, 25, 15, 10];
new Chart(document.getElementById('bar'), { type: 'bar', data: { labels, datasets: [{ label: 'Stats', data: d1, backgroundColor: '#4f46e5' }] } });
new Chart(document.getElementById('pie'), { type: 'pie', data: { labels, datasets: [{ data: d2, backgroundColor: ['red','blue','green','yellow','orange','purple','cyan'] }] } });