const data = [
    {id:1, name:"Item 1", price:10}, {id:2, name:"Item 2", price:20}, 
    {id:3, name:"Item 3", price:30}, {id:4, name:"Item 4", price:40}, 
    {id:5, name:"Item 5", price:50}, {id:6, name:"Item 6", price:60}
];
let cart = [];
function show() {
    const shop = document.getElementById("shop");
    shop.innerHTML = data.map(i => `<div class="col-md-4"><div class="card"><h3>${i.name}</h3><h2>$${i.price}</h2><button class="btn btn-primary" onclick="add(${i.id})">Add</button></div></div>`).join("");
}
function add(id) { cart.push(data.find(i => i.id === id)); set(); }
function set() {
    const bag = document.getElementById("bag"); let total = 0;
    bag.innerHTML = cart.map(i => { total += i.price; return `<p>${i.name} - $${i.price}</p>`; }).join("");
    document.getElementById("val").innerText = "$" + total;
}
show();