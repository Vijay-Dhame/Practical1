# Q7_Small_Business_Landing

This is a static HTML/CSS/JS assignment.

## Quick Run
Copy and paste this into your terminal (run from the project root):
```powershell
cd FSD_Assignments/Assignment_2/Q7_Small_Business_Landing; npx serve .
```

## Alternative
1. Right-click on `index.html` and select **Open with Live Server**.
2. Or simply open `index.html` in any browser.
