const express = require('express');
const connectDB = require('./config/db');
const cors = require('cors');
const path = require('path');
const app = express();
const authRoutes = require('./routers/auth');
const cartRoutes = require('./routers/cart');

app.use(cors());
app.use(express.json());
connectDB();

// Serve frontend static files from the parent folder
app.use(express.static(path.join(__dirname, '..')));

// Root route — serves index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

app.use('/api', authRoutes);
app.use('/api/cart', cartRoutes);

app.listen(8000, () => {
    console.log(`Server running on port 8000`);
    console.log(`Open: http://localhost:8000`);
});