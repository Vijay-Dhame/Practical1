const signinForm = document.getElementById('signupForm');
if(signinForm){
        signinForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        fetch("http://localhost:8000/api/signup",{
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        })
        .then(response => response.json())
        .then(data => {
            if(data.message === "User registerd successfukky" || data.message === "User registered successfully") {
                alert("Signup successful!");
                window.location.href = "login.html";
            }else{
                alert("Signup failed: " + data.message);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred during signup.");
        });
    });

}

const loginForm = document.getElementById('loginForm');
if (loginForm) {
loginForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    fetch("http://localhost:8000/api/login", {
        method: "POST",
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify({
            email:email,
            password:password
        })
    })

    .then(response => response.json())
    .then(data => {
        if(data.message === "Login successful"){
            localStorage.setItem('token', data.token); // Save JWT token
            alert('login successful !');
            window.location.href = 'index.html';
        }else {
            alert('Error: '+data.message);
        }
    })
    .catch(error => {
        alert('Server error: ' + error)
    });
});  // end loginForm listener
}


// ── CART LOGIC (MongoDB) ──
const getAuthHeaders = () => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` });

document.querySelectorAll('.add-to-cart-btn').forEach(btn => btn.addEventListener('click', async () => {
    if(!localStorage.getItem('token')) return alert("Please login first!");
    let { name, desc } = btn.closest('.card').dataset;
    let res = await fetch('http://localhost:8000/api/cart/add', { method: 'POST', headers: getAuthHeaders(), body: JSON.stringify({name, desc, qty: 1}) });
    if(res.ok) { btn.textContent = '✓ Added'; btn.disabled = true; alert(`${name} added!`); }
    else { let err = await res.json(); alert(err.message); }
}));

const cartContainer = document.getElementById('cart-container');
const fetchAndRenderCart = async () => {
    if(!localStorage.getItem('token')) return cartContainer.innerHTML = '<p style="text-align:center;">Please log in to view your cart.</p>';
    let res = await fetch('http://localhost:8000/api/cart', { headers: getAuthHeaders() });
    if(!res.ok) return cartContainer.innerHTML = '<p style="text-align:center;">Error loading cart.</p>';
    let cart = await res.json();
    cartContainer.innerHTML = cart.length ? cart.map(i => `<div class="card"><h3>${i.name}</h3><p>${i.desc}</p><div class="qty-controls"><button class="qty-btn minus" data-name="${i.name}" data-qty="${i.qty}">−</button><span>${i.qty}</span><button class="qty-btn plus" data-name="${i.name}" data-qty="${i.qty}">+</button></div><button class="remove-btn" data-name="${i.name}">Remove</button></div>`).join('') : '<p style="text-align:center;">Your cart is empty!</p>';
};

if (cartContainer) {
    fetchAndRenderCart();
    cartContainer.addEventListener('click', async e => {
        let name = e.target.dataset.name;
        if (!name) return;
        
        if (e.target.classList.contains('plus')) {
            let qty = parseInt(e.target.dataset.qty) + 1;
            await fetch('http://localhost:8000/api/cart/update', { method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify({name, qty}) });
        }
        if (e.target.classList.contains('minus')) {
            let qty = parseInt(e.target.dataset.qty) - 1;
            await fetch('http://localhost:8000/api/cart/update', { method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify({name, qty}) });
        }
        if (e.target.classList.contains('remove-btn')) {
            await fetch(`http://localhost:8000/api/cart/remove/${name}`, { method: 'DELETE', headers: getAuthHeaders() });
        }
        fetchAndRenderCart();
    });
    document.getElementById('clear-cart-btn')?.addEventListener('click', async () => { 
        await fetch('http://localhost:8000/api/cart/clear', { method: 'DELETE', headers: getAuthHeaders() }); 
        fetchAndRenderCart(); 
    });
}
